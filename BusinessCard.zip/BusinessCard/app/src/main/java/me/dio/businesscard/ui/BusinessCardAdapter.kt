package me.dio.businesscard.ui

import android.view.View
import android.widget.ListAdapter
import me.dio.businesscard.data.BusinessCard
import me.dio.businesscard.databinding.ItemBusinessCardBinding

class BusinessCardAdapter :
    ListAdapter<BusinessCard, BusinessCardAdapter.ViewHolder>(DiffCallBack()) {

    var listenerShare: (View) -> Unit = {}

    inner class ViewHolder{
        private val binding: ItemBusinessCardBinding
    } : RecyclerView.ViewHolder(binding.root){
        fun bind (item: BusinessCard){
            binding.tvNome.text = item.nome
        }
    }
}